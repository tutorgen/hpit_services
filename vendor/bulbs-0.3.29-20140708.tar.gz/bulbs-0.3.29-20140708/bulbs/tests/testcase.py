import unittest

class BulbsTestCase(unittest.TestCase):

    client = None
    index_class = None
    
